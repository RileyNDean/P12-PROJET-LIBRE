//
//  DressingFormView.swift
//  My E-Dressing
//
//  Created by Dhayan Bourguignon on 10/10/2025.
//

import SwiftUI
import CoreData

/// Create or rename a dressing.
struct DressingFormView: View {
    @Environment(\.dismiss) private var dismiss
    @Environment(\.managedObjectContext) private var managedObjectContext

    var editingDressing: Dressing? = nil

    @State private var nameText: String = ""
    @State private var isShowingAlert: Bool = false
    @State private var alertMessage: String = ""

    var body: some View {
        NavigationStack {
            Form {
                TextField(String(localized: "name"), text: $nameText)
            }
            .navigationTitle(editingDressing == nil ? String(localized: "new_dressing") : String(localized: "rename"))
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button(String(localized: "cancel")) { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button(String(localized: "save")) { save() }
                        .disabled(nameText.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
                }
            }
            .onAppear {
                if let editingDressing { nameText = editingDressing.name ?? "" }
            }
            .alert(String(localized: "error_title"), isPresented: $isShowingAlert) {
                Button(String(localized: "ok"), role: .cancel) {}
            } message: { Text(alertMessage) }
        }
    }

    private func save() {
        do {
            let controller = DressingController(managedObjectContext: managedObjectContext)
            if let editingDressing {
                try controller.rename(editingDressing, to: nameText)
            } else {
                _ = try controller.create(name: nameText)
            }
            dismiss()
        } catch let error as ValidationError {
            alertMessage = error.message; isShowingAlert = true
        } catch {
            alertMessage = String(localized: "unexpected_error"); isShowingAlert = true
        }
    }
}

//
//  Untitled.swift
//  My E-Dressing
//
//  Created by Dhayan Bourguignon on 10/10/2025.
//

import SwiftUI
import CoreData

/// Lists all dressings. Lets user create, rename and delete. Navigates to garments.
struct DressingListView: View {
    @Environment(\.managedObjectContext) private var managedObjectContext

    @FetchRequest(
        sortDescriptors: [NSSortDescriptor(keyPath: \Dressing.createdAt, ascending: true)],
        animation: .default
    )
    private var fetchedDressings: FetchedResults<Dressing>

    @State private var isPresentingNewDressingForm: Bool = false
    @State private var editingDressing: Dressing? = nil
    @State private var isShowingAlert: Bool = false
    @State private var alertMessage: String = ""

    var body: some View {
        NavigationStack {
            List {
                ForEach(fetchedDressings) { dressing in
                    NavigationLink {
                        GarmentListView(dressing: dressing)
                    } label: {
                        HStack {
                            Text(dressing.name ?? String(localized: "unnamed"))
                            Spacer()
                            Text("\(dressing.garments?.count ?? 0)")
                                .foregroundStyle(.secondary)
                        }
                    }
                    .contextMenu {
                        Button(String(localized: "rename")) { editingDressing = dressing }
                        Button(role: .destructive) {
                            deleteDressings([dressing])
                        } label: { Text(String(localized: "delete")) }
                    }
                }
                .onDelete { indexSet in
                    let toDelete = indexSet.map { fetchedDressings[$0] }
                    deleteDressings(toDelete)
                }
            }
            .navigationTitle(String(localized: "dressings_title"))
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button(action: { isPresentingNewDressingForm = true }) { Image(systemName: "plus") }
                }
            }
            .sheet(isPresented: $isPresentingNewDressingForm) {
                DressingFormView()
            }
            .sheet(item: $editingDressing) { dressing in
                DressingFormView(editingDressing: dressing)
            }
            .alert(String(localized: "error_title"), isPresented: $isShowingAlert) {
                Button(String(localized: "ok"), role: .cancel) {}
            } message: { Text(alertMessage) }
        }
    }

    private func deleteDressings(_ dressings: [Dressing]) {
        do {
            let controller = DressingController(managedObjectContext: managedObjectContext)
            try dressings.forEach { try controller.delete($0) }
        } catch {
            alertMessage = String(localized: "unexpected_error")
            isShowingAlert = true
        }
    }
}

